package com.cg.bankapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class BankExceptionController
{
	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity<String> ("Error: "+ex.getMessage(),HttpStatus.CONFLICT);
	}
}

