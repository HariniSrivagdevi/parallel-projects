package com.plp.springrest.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TransactionEntity")
public class Transaction {
	
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="transID")
	    @SequenceGenerator(name="transID", initialValue=100, allocationSize=1, sequenceName = "trans_Seq")
	    @Column(name="Trans_AccNo", updatable=false, nullable=false)
		private int transactionId;
		private String transactionType;
		private long AccountNumber;
		private double amount;
		
		//Generating getters and setters
		
		public int getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(int transactionId) {
			this.transactionId = transactionId;
		}
		public String getTransactionType() {
			return transactionType;
		}
		public void setTransactionType(String transactionType) {
			this.transactionType = transactionType;
		}
		public long getAccountNumber() {
			return AccountNumber;
		}
		public void setAccountNumber(long accountNumber) {
			AccountNumber = accountNumber;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		
		//Generation of toString Method
		@Override
		public String toString() 
		{
			return "TransactionEntity [transactionId=" + transactionId + ", transactionType=" + transactionType
					+ ", AccountNumber=" + AccountNumber + ", amount=" + amount + "]";
		}	
		
	}
	
