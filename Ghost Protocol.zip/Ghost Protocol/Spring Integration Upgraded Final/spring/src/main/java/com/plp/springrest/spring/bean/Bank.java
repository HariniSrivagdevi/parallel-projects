package com.plp.springrest.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="banking_details")
public class Bank 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqId")
    @SequenceGenerator(name="seqId", initialValue=79972800, allocationSize=500, sequenceName = "Account_id")
	
	private int accountId;
	//@Pattern(regexp="[A-Z][a-z]*")
	private String username;
	private double balance;
	//@Pattern(regexp="(91)||(91)?[6-9][0-9]{9}")
	private String phoneNumber;
	private String password;
	
	//Generation of Getters and Setters
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "Bank [accountId=" + accountId + ", username=" + username + ", balance=" + balance + ", phoneNumber="
				+ phoneNumber + ", password=" + password + "]";
	}
	
}
