import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerServiceService } from '../customer-service.service';
@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  
  transactionType:number;
  constructor(private customerService : CustomerServiceService) { }

  ngOnInit() {
  }
  printTransaction(accnum): number
  {
  this.customerService.printTransaction(accnum).subscribe(data=>{
  this.transactionType=data;
  console.log(this.transactionType);  
})
return this.transactionType;
  }
   

}
