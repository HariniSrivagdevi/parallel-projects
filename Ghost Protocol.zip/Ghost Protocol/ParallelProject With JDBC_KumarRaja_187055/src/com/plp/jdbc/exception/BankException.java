package com.plp.jdbc.exception;

@SuppressWarnings("serial")

public class BankException extends Exception {
	String s1;

	public BankException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}
}
