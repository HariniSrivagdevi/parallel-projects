package com.plp.jdbc.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.plp.jdbc.bean.Banking;
import com.plp.jdbc.bean.Transactions;
import com.plp.jdbc.dao.BankDao;
import com.plp.jdbc.dao.BankDaoImpl;
import com.plp.jdbc.exception.BankException;

public class BankServiceImpl implements BankService{

	BankDao dao = new BankDaoImpl();
	
	@Override
	public void accountCreate(Banking bank,Transactions tran) {
		dao.accountCreate(bank,tran);
	}

	@Override
	public String balCheck(int accNo) {
		return  dao.balCheck(accNo);
	}

	@Override
	public String addMoney(int accNumber, long amt, Transactions tran) {
		return  dao.addMoney(accNumber, amt, tran);
	}

	@Override
	public String withdrawMoney(int accNumber, long amt, Transactions tran) {
		return  dao.withdrawMoney(accNumber, amt, tran);
	}


	@Override
	public String moneyTransfer(int accNumber1, long amt1, int accNumber2,Transactions tran1,Transactions tran2) {
		return dao.moneyTransfer(accNumber1,amt1,accNumber2,tran1,tran2);
	}

	@Override
	public String getTransactionDetails(int accNumber) {
		
		HashMap<Integer,Transactions> hm = dao.printTransactions(accNumber);
		Set set = hm.entrySet();
		Iterator iterator = set.iterator();
		String trans = "" ;
		while(iterator.hasNext())
		{
			Map.Entry pair = (Map.Entry)iterator.next();
			int transid=(int) pair.getKey();
			Transactions transaction=(Transactions) pair.getValue();
			trans=trans+"\n"+"Transaction ID :"+transid+"|| Account number :"+transaction.getAcno()+"|| Transaction Type :"+transaction.getOpertaion();
		}
		return trans;
	}
}
